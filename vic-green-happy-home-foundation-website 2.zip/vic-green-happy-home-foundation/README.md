# Vic Green Happy Home Foundation

Professional responsive website for Vic Green Happy Home Foundation.

## Files
- `index.html` — website structure and content
- `style.css` — responsive design
- `script.js` — mobile navigation and registration interaction

## Before publishing
Replace the placeholder email, phone number and location in `index.html` with the foundation's official details.

The registration form is currently a front-end demo. Connect it to a trusted form/backend service before collecting real personal information.

## GitHub Pages
Upload all files to the root of the `main` branch, then use **Settings → Pages → Deploy from a branch → main → /(root)**.
