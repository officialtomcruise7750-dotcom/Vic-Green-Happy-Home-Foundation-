# Vic Green Happy Home Foundation Website

A free, static NGO website ready for GitHub Pages.

## Before publishing
Open `index.html` and replace:
- `YOUR_EMAIL@example.com`
- `+234 XXX XXX XXXX`
- `Location: Nigeria`
- the placeholder impact numbers
- any wording that does not accurately describe the foundation's real activities

## Publish for free
Use a public GitHub repository and GitHub Pages. See:
https://docs.github.com/en/pages/quickstart
